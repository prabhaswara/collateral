/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gun.latihan.spring.controller;


import com.gun.latihan.spring.form.KaryawanFrm;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



/**
 *
 * @author prabhaswara
 */
@Controller
@RequestMapping("/karyawan")
public class KaryawanController  {
    
  
    private final static Logger log = Logger.getLogger(KaryawanController.class.getName());

  
    
    @RequestMapping(value = "/create", method = RequestMethod.GET)
    public String create(ModelMap map) {
        log.info("gunawan create karyawan");
        KaryawanFrm frm = new KaryawanFrm();
        map.put("karyawanFrm", frm);
        return "karyawan/create";
        
    }
   
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public String createPost(@ModelAttribute("frm") KaryawanFrm frm,
            ModelMap map) {
        
        try {
         
        } catch (Exception e) {
            log.log(Level.WARNING, e.getMessage());
        }
         map.put("karyawanFrm", frm);
        return "karyawan/create";
    }
    
    
   
  
}
